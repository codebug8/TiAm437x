#ifndef  __DELAY_H__
#define  __DELAY_H__

extern void  delay(unsigned int   i);
extern void  delay_ms(unsigned int    i);

#endif