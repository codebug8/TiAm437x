#ifndef   __MY_PRINTF_H__
#define   __MY_PRINTF_H__

#define printf _100ask_printf

extern void  _100ask_printf(char *fmt,...);
extern int   _100ask_printf_test(void);

#endif
