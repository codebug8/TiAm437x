#ifndef  __DELAY_H__
#define  __DELAY_H__

extern void  delay(unsigned int   i);

#endif