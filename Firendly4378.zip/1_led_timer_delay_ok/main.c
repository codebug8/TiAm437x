/*************************************************************************
    > File Name: main.c
    > Author: hceng
    > Description: AM437X裸机timer
    > Created Time: 20170811
*************************************************************************/

#include "AM437X/AM437X_SOC.h"
#include "led.h"
#include "delay.h"


int  main()
{

	led_init();
	


	return 0;
}




